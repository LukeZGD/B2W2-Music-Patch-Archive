Pokemon FireRed, LeafGreen, Emerald, Ruby, and Sapphire - BW/B2W2 Music Patch v1.3!

BW/B2W2 Music Patch is a patch for Pokemon FireRed (1.0), LeafGreen (1.0), Emerald, Ruby (1.1), and
Sapphire (1.0) that replaces the original songs with the ones from Pokemon Black and White, and
from Black 2 and White 2!
Most of the songs and fanfares are included.
This patch is based on the HGSS Music Patch (Emerald v1.4 Instruments.bit), 
so big credits to the creators of it!

Programs Used:
FL Studio
Anvil Studio
VGMTrans
Viena
midfix4agb (credits to ipatix)
HxD
Mid2Agb
Sappy

Please make backups before applying this patch! I am not responsible if you ruin your ROM after
applying.

- This version of the patch contains ipatix's music mixer, and it has higher quality
sound than the other versions.

- For the songs that change every season, only the Spring version is included in this patch.

How to patch: 
Extending the ROM is REQUIRED, do this before proceeding. XSE is what I use to do this.
1. Apply the .ips patch to your ROM (Use the correct one!)
2. Open the file "B2W2 Music Patch v1.3.bit" in HxD. (Use the version for your ROM)
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there.
6. Save!

To play in Sappy without any issues do the following: 
Sappy Mod 15 - 17.1 -> Options -> Settings -> Extra -> DirectSound Voices Limit = 12

Songtable locations:
FireRed - 0x14BEC00
Ruby - 0x14BFC00
Sapphire and LeafGreen - 0xF00000
Emerald - 0x6B49F0 (same)
You can use the sappy.xml included as replacement.

Changes in v1.3:
-Fixed some of the music:
vs Ghetsis BW
Encounter Psychic

-Added A LOT of B2W2 and other music/fanfares:
Wild Battle B2W2 
Trainer Battle B2W2 
Aspertia City 
Gym Leader Battle B2W2 
Neo Plasma Battle 
Route 22 Spring 
Route 23
Colress Battle 
Hugh Battle 
Route 19 Spring 
Virbank City 
Entralink 
Unity Tower 
B2W2 Intro 1 
B2W2 Intro 2 
Encounter Cheren B2W2 
Encounter Bianca B2W2 
vs Ghetsis B2W2 
Battle Black/White Kyurem 
Encounter Team Plasma B2W2 
Team Plasma, Again 
Encounter Colress
Marine Tube
Encounter Hugh
PWT Finals!
Flocessy Ranch
Flocessy Town
Castelia Sewers
BP Get
Regi Trio Battle
Sealed Chamber (Regi)
Strange House
PWT Lobby

-Low Health Beep is now shortened to be a lot less annoying
(Can't find a way to implement low health music yet)
-Made changes to the songtables to have B2W2 music as default
-The original BW music is relocated to a different location in the songtables
-Made minor changes in sappy.xml (for MRDS base)
-Fixed crackling of Pokemon cries (Emerald)

-v1.3 is for FireRed and Emerald ONLY for now. Will add support for R/S/LG in later versions next year.

Credits:
LukeeGD (me)
The people behind HGSS Music Patch: GoGoJJTech, Wobbu
ipatix (midfix4agb and the music mixer ASM hack)

Big credits to them, because without them, this patch would take longer to make!

LINKS:
PokeCommunity Thread: https://www.pokecommunity.com/showthread.php?t=402253
HGSS Music Patch: http://www.pokecommunity.com/showthread.php?t=308411
My Twitter: https://twitter.com/lukee_gd_
