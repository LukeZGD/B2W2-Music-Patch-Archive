Pokemon FireRed - BW Music Patch 2017 v1.1 RC1 (FireRed, Emerald) / Alpha 1 (Ruby)

NOT FINAL RELEASE YET, DO NOT USE IT AS A ROMBASE!!!!

How to patch it (FireRed):
(Extending the ROM is recommended, but not required)
1. Apply the [FR]/[RU] .ips patch to your ROM
2. Open the file "build [FR].bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the FireRed ROM in HxD.
5. Go to (Ctrl+G) 1000000 and paste-write (Ctrl+B) the copied content there. It will ask you that the operation changes the file size, click OK to proceed, and save!

How to patch it (Emerald):
(Extending the ROM is REQUIRED, do this before proceeding)
1. Apply the [EM] .ips patch to your ROM
2. Open the file "build [EM].bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the Emerald ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there. It will ask you that the operation changes the file size, click OK to proceed, and save!

Credits:
The people behind HGSS Kanto Reloaded/HGSS Music Patch: GoGoJJTech, Wobbu, and Ruki Makino

Full Song List:
https://docs.google.com/document/d/1JeEVjhYLnyIprxqykkrYqLDXDlOPhttUF7o6PRyb7HI/edit?usp=sharing