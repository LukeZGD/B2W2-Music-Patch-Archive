B2W2 Music Patch Source Files! (as of v1.3)
As you will see in the files, everything was done manually, no automated scripts at all.

When using anything here, please give visible credit to me (LukeeGD)