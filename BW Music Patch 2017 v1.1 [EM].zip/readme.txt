Pokemon FireRed and Emerald - BW Music Patch 2017 v1.1!

Pokemon BW Music Patch 2017 is a patch for Pokemon FireRed and Emerald that replaces the
original songs with the ones from Pokemon Black and White!
This patch is based on the HGSS Kanto Reloaded patch (FireRed) and HGSS Music Patch (Emerald),
so big credits to the creators of it!

WARNING: I am not responsible if you apply this patch to your
ROM and ruin it, although it is compatible with hacks in progress.

How to patch it (FireRed):
(Extending the ROM is recommended, but not required)
1. Apply the .ips patch to your ROM
2. Open the file "build [FR].bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the FireRed ROM in HxD.
5. Go to (Ctrl+G) 1000000 and paste-write (Ctrl+B) the copied content there. It will ask you that the operation changes the file size, click OK to proceed, and save!

How to patch it (Emerald):
(Extending the ROM is REQUIRED, do this before proceeding)
1. Apply the .ips patch to your ROM
2. Open the file "build [EM].bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the Emerald ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there. It will ask you that the operation changes the file size, click OK to proceed, and save!

Changes in v1.1:
- More songs
374 - Dive/Ruins
375 - Encounter Team Plasma 
376 - Plasma Defeat 
377 - N�s Room 
378 - The Day I Became King
379 - Lostlorn Forest 

- Fixed some songs! (also includes changes from v1.0.1 and the unreleased v1.0.2)
265 - Elite Four Battle (V2)
282 - Bicycle (V2)
286 - Hall of Fame (V2)
289 - Team Plasma Battle (V2)
290 - End Credits (V2)
293 - Route 2 Spring (V2)
296 - Gym Leader Battle (V2)
297 - Trainer Battle (V2)
305 - Surfing (V2)
324 - Opelucid City (Black) (V2)
340 - Reshiram/Zekrom Battle (V2)
348 - vs N Final (V2)

- Fully ported to Emerald! This includes all the new and fixed songs.

Credits:
If used, give credits to me (LukeeGD) and the people behind HGSS Kanto Reloaded/HGSS Music Patch: GoGoJJTech,
Wobbu, and Ruki Makino. Big credits to them, because without them, this patch would take a lot longer to make!

LINKS

Full Song List: https://docs.google.com/document/d/1JeEVjhYLnyIprxqykkrYqLDXDlOPhttUF7o6PRyb7HI/edit?usp=sharing

HGSS Kanto Reloaded: https://www.pokecommunity.com/showthread.php?t=342914
HGSS Music Patch: http://www.pokecommunity.com/showthread.php?t=308411

My Twitter: https://twitter.com/lukee_gd_
