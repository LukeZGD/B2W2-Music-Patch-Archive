Pokemon FireRed - BW Music Patch 2017 v1.0.1!

Pokemon BW Music Patch 2017 is a patch for Pokemon FireRed that replaces songs of FireRed with
the ones from Pokemon Black and White!
This patch is based on the HGSS Kanto Reloaded patch, so big credits to the creators of it!

Changes:
23 new songs
Improved sound quality
Smaller filesize than Alpha 2

WARNING: I am not responsible if you apply this patch to your
ROM and ruin it, although it is compatible with hacks in progress.

How to patch it: 
(Extending the ROM is recommended, but not required)
1. Apply the .ips patch to your ROM (use the old patch for ROM hacks and the new patch for unmodified ROMs and ROM bases)
2. Open the file "build.bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the FireRed ROM in HxD.
5. Go to (Ctrl+G) 1000000 and paste-write (Ctrl+B) the copied content there. It will
ask you that the operation changes the file size, click OK to proceed, and save!

HGSS Kanto Reloaded: https://www.pokecommunity.com/showthread.php?t=342914

The Music:

For the full song list, go here:
https://docs.google.com/document/d/1JeEVjhYLnyIprxqykkrYqLDXDlOPhttUF7o6PRyb7HI/edit?usp=sharing