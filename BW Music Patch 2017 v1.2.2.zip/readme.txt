Pokemon FireRed, LeafGreen, Emerald, Ruby, and Sapphire - BW Music Patch v1.2.2!

BW Music Patch is a patch for Pokemon FireRed (1.0), LeafGreen (1.0), Emerald, Ruby (1.1), and
Sapphire (1.0) that replaces the original songs with the ones from Pokemon Black and White!
Most of the songs and fanfares are included.
This patch is based on the HGSS Music Patch (Emerald v1.4 Instruments.bit), 
so big credits to the creators of it!

Programs Used:
FL Studio
Anvil Studio
VGMTrans
Viena
midfix4agb (credits to ipatix)
HxD
Mid2Agb
Sappy

Please make backups before applying this patch! I am not responsible if you ruin your ROM after
applying.

- The FireRed and Emerald versions of the patch contains ipatix's music mixer, and it has higher quality
sound than the other versions.

- For the songs that change every season, only the Spring version is included in this patch.

How to patch: 
Extending the ROM is REQUIRED, do this before proceeding. XSE can do this for you.
1. Apply the .ips patch to your ROM (Use the correct one!)
2. Open the file "BW Music Patch v1.2.bit" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there.
6. Save!

To play in Sappy without any issues do the following: 
Sappy Mod 15 - 17.1 -> Options -> Settings -> Extra -> DirectSound Voices Limit = 12

Songtable locations:
FireRed - 0x14BEC00
Ruby - 0x14BFC00
Sapphire and LeafGreen - 0xF00000
Emerald - same
You can use the sappy.xml included as replacement.

Changes in v1.2.2:
- Bug fixes: The music freezing bug is now completely gone! (as far as I've tested)
- Removed the "no mixer" version of Emerald. The music mixer is no longer in a separate offset!
- Added ipatix's music mixer on FireRed!
- Fixed introduction music not playing on Ruby and Sapphire

Changes in v1.2.1:
- Added 2 fanfares
- (Emerald both versions) Fix song header for 435 (Pokemon Trainer School)
- (Emerald with mixer) Fix Oldale Town music
- (LeafGreen) Fix the IPS patch

Changes in v1.2:
- No longer based on HGSS Kanto Reloaded
- Moved from 1000000 to 1200000 for cross-compatibility to all versions (and more supported ROM hacks?)
- Moved songtable to 14BEC00 (FireRed) / 14BFC00 (Ruby) / F00000 (Sapphire, LeafGreen)
- Made all of the songs more like the original!
- Now included a version of the Emerald patch with ipatix's music mixer
- Fully ported to Ruby, Sapphire, and LeafGreen!
The Ruby and Sapphire versions will have problems playing the music because of limitations.

Credits:
LukeeGD (me)
The people behind HGSS Music Patch: GoGoJJTech, Wobbu
ipatix (midfix4agb and the music mixer ASM hack)

Big credits to them, because without them, this patch would take longer to make!

LINKS:
Full Song List: https://docs.google.com/document/d/1JeEVjhYLnyIprxqykkrYqLDXDlOPhttUF7o6PRyb7HI/edit?usp=sharing
HGSS Music Patch: http://www.pokecommunity.com/showthread.php?t=308411
My Twitter: https://twitter.com/lukee_gd_
