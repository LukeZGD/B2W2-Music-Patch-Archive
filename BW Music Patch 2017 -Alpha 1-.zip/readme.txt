Here it is, the BW Music Patch Alpha 1!!

This patch replaces the songs of FireRed for music from Pokemon Black and White.
This patch is still very incomplete, so many songs are still not included. 
This patch is based on HGSS Kanto Reloaded Music, which is based on GoGoJJTech's HGSS
music patch.

As of now, I recommend you to patch this on a stock FireRed ROM only, and not use it in ROM
hacks or as a base, because this is still in Alpha stages and will be updated over time.

REMEMBER: I am not responsible if you apply this patch to your
ROM and ruin it, although it is compatible with hacks in progress.

How to install:
1. Apply the .ips patch to your ROM
2. open the file "build.bin" in a hex editor (I use HxD), select the whole file and copy it
3. Open your ROM in HXD and go to 0x1000000, paste the copied content there,
then it will ask you that the action changes the file size, click Yes, then save!

Credits:
If used, give credits to me (LukeeGD) and the authors of the HGSS Kanto Reloaded: GoGoJJTech,
Wobbu, and Ruki Makino.

HGSS Kanto Reloaded: https://www.pokecommunity.com/showthread.php?t=342914

The Music:
Here's a list of the BW music that I have put in this patch as of Alpha 1.

277 - Intro
278 - Titlescreen
292 - Welcome to the World of Pok�mon
300 - Nuvema Town
302 - Prof Theme
301 - Prof Lab
297 - Trainer Battle
266 - Rival Battle
314 - Accumula Town
291 - Route 1
298 - Wild Battle
257 - Level Up
293 - Route 2 Spring
284 - Encounter Lass
285 - Encounter Youngster
321 - Gamefreak
335 - Striaton City
308 - Nacrene City
303 - Pokemon Center
272 - Come Along 2
275 - Gym
296 - Gym Leader Battle
282 - Bicycle
305 - Surfing
287 - Dreamyard
288 - Chargestone Cave
294 - Route 6 Spring
309 - Nimbasa City
313 - Castelia City
346 - Gate
290 - End Credits
