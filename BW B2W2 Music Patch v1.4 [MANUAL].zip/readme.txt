Pokemon FireRed, LeafGreen, Emerald, Ruby, and Sapphire - BW/B2W2 Music Patch v1.4!

BW/B2W2 Music Patch is a patch for Pokemon FireRed (1.0), LeafGreen (1.0), Emerald, Ruby (1.1), and
Sapphire (1.0) that replaces the original songs with the ones from Pokemon Black and White, and
from Black 2 and White 2!
Most of the songs and fanfares are included.
This patch is based on the HGSS Music Patch (Emerald v1.4 Instruments.bit), 
so big credits to the creators of it!

Programs Used:
FL Studio
Anvil Studio
VGMTrans
Viena
midfix4agb (credits to ipatix)
HxD
Mid2Agb
Sappy

Please make backups before applying this patch! I am not responsible if you ruin your ROM after
applying.

- For the songs that change every season, only the Spring version is included in this patch. 

- This patch includes ipatix's music mixer, and it makes the music have less noise.

-This patch is compatible with the All Instrument Patch, where you can insert songs with a universal
All Instrument voicegroup on top of the B2W2 ones.

-The FireRed patch is compatible with MrDollSteak�s Decap and Attack Rombase, if you use that.

How to patch [MANUAL]: 
Extending the ROM is REQUIRED, do this before proceeding. XSE is what I use to do this.
1. Apply the .ips patch to your ROM (Use the correct one!)
2. Open the file "B2W2 Music Patch v1.4.bit" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there.
6. Save!

To play in Sappy without any issues do the following: 
Sappy Mod 15 - 17.1 -> Options -> Settings -> Extra -> DirectSound Voices Limit = 12

Songtable locations:
FireRed - 0x14BEC00
Ruby - 0x14BFC00
Sapphire and LeafGreen - 0xF00000
Emerald - 0x6B49F0 (same)
You can use the sappy.xml included as replacement.

Music mixer locations:
FireRed - 0x15E9DC0
Emerald - 0x15E9280
Ruby - 0x1776C00 (v1.3.1 and above) / 0x15EA560 (v1.2.3)
Sapphire and LeafGreen - 0xB00000

Changes in v1.4:
-More B2W2 music added:
Kanto Gym Leader 
Kanto Champion 
Johto Gym Leader 
Johto Champion 
Hoenn Gym Leader 
Hoenn Champion
Sinnoh Gym Leader
Sinnoh Champion 
Champion Iris Battle 
Humilau City 
vs N B2W2 
Lentimas Town 
Gym Leader Last Pokemon B2W2 
Road to Reversal Mountain 
Reversal Mountain (Black2) 
Reversal Mountain (White2) 

-Adjust some songs in the songtables (again)
-New Acoustic Guitar samples
-New Accordion samples
-Amplified B2W2 Electric Guitar samples
-Removed some unused HGSS sample data left over from HGSS music patch
-Relocated multi-sample data (will be used in future update)
-Relocated some voicegroups to give way for free space (will be useful for future update)
-More minor fixes I haven't mentioned

-I also made UPS patches for more convenient patching! 

Credits:
LukeeGD (me)
The people behind HGSS Music Patch: GoGoJJTech, Wobbu
ipatix (midfix4agb and the music mixer ASM hack)

Big credits to them, because without them, this patch would take longer to make!

LINKS:
PokeCommunity Thread: https://www.pokecommunity.com/showthread.php?t=402253
HGSS Music Patch: http://www.pokecommunity.com/showthread.php?t=308411
My Twitter: https://twitter.com/lukee_gd_
