Pokemon FireRed, Emerald and Ruby - BW Music Patch v1.2 RC1!

BW Music Patch is a patch for Pokemon FireRed, Emerald and Ruby that replaces the
original songs with the ones from Pokemon Black and White!
This patch is based on the HGSS Music Patch, so big credits to the creators of it!

Programs Used:
FL Studio
Anvil Studio
VGMTrans
Viena
midfix4agb (credits to ipatix)
Mid2Agb
Sappy

Please make backups before applying this patch! I am not responsible if you ruin your ROM after
applying.

How to patch:
(Extending the ROM is REQUIRED, do this before proceeding)
1. Apply the .ips patch to your ROM (use the correct one!)
2. Open the file "BW Music Patch v1.2.bit" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the ROM in HxD.
5. Go to (Ctrl+G) 1200000 and paste-write (Ctrl+B) the copied content there.
It will ask you that the operation changes the file size, click OK to proceed, and save!

Changes in v1.2:
- No longer based on HGSS Kanto Reloaded
- Moved from 1000000 to 1200000 for cross-compatibility to all versions (and more supported ROM hacks)
- Moved songtable to 14BEC00 (FireRed) / 14BFC00 (Ruby) / F00000 (Sapphire, LeafGreen)
- Made all of the songs more like the original!
- Fully ported to Ruby, Sapphire, and LeafGreen!
The Ruby and Sapphire versions will have problems playing the music because of limitations.

Credits:
If used, give credits to me (LukeeGD) and the people behind HGSS Music Patch: GoGoJJTech, Wobbu. 
Big credits to them, because without them, this patch would take longer to make!

LINKS:
Full Song List: https://docs.google.com/document/d/1JeEVjhYLnyIprxqykkrYqLDXDlOPhttUF7o6PRyb7HI/edit?usp=sharing
HGSS Music Patch: http://www.pokecommunity.com/showthread.php?t=308411
My Twitter: https://twitter.com/lukee_gd_
