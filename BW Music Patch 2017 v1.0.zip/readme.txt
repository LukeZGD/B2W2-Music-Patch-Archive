Pokemon FireRed - BW Music Patch 2017 v1.0!

Pokemon BW Music Patch 2017 is a patch for Pokemon FireRed that replaces songs of FireRed with
the ones from Pokemon Black and White!
This patch is based on the HGSS Kanto Reloaded patch, so big credits to the creators of it!

Changes:
23 new songs
Improved sound quality
Smaller filesize than Alpha 2

WARNING: I am not responsible if you apply this patch to your
ROM and ruin it, although it is compatible with hacks in progress.

How to patch it: 
(Extending the ROM is recommended, but not required)
1. Apply the .ips patch to your ROM (use the old patch for ROM hacks and the new patch for unmodified ROMs and ROM bases)
2. Open the file "build.bin" in HxD.
3. Select all of the contents (Ctrl+A) and copy it (Ctrl+C).
4. Open the FireRed ROM in HxD.
5. Go to (Ctrl+G) 1000000 and paste-write (Ctrl+B) the copied content there. It will
ask you that the operation changes the file size, click OK to proceed, and save!

HGSS Kanto Reloaded: https://www.pokecommunity.com/showthread.php?t=342914

The Music:
Here's a list of the BW music that I have put in this patch as of v1.0!
The ones not listed stay the same as is at the HGSS patch.

257 - Level Up
263 - Evolution Start
265 - Elite Four Battle
266 - Rival Battle (V2)
267 - Battle Rare Wild Pokemon
272 - Come Along 2
273 - Battle Subway
274 - Encounter Team Plasma
275 - Gym
276 - Unwavering Emotions
277 - Intro
278 - Titlescreen (V2)
279 - Undella Town Summer
280 - Lacunosa Town
282 - Bicycle
283 - Encounter Scientist
284 - Encounter Lass
285 - Encounter Youngster
286 - Hall of Fame
287 - Dreamyard
288 - Chargestone Cave
289 - Team Plasma Battle
290 - End Credits
291 - Route 1
292 - Welcome to the World of Pok�mon / Route 4
293 - Route 2 Spring
294 - Route 6 Spring
295 - Victory Road
296 - Gym Leader Battle
297 - Trainer Battle
298 - Wild Battle
299 - Champion Battle
300 - Nuvema Town
301 - Prof Lab
302 - Prof Theme
303 - Pok�mon Center
304 - Cruiseferry SS Royal Unova
305 - Surfing
306 - Dragonspiral Tower
307 - Cold Storage
308 - Nacrene City
309 - Nimbasa City
313 - Castelia City
314 - Accumula Town
315 - Rival Cheren Theme
316 - Rival Cheren Theme
321 - Gamefreak
323 - vs N
324 - Opelucid City (Black) 
325 - Opelucid City (White) 
326 - N's Castle Bridge
327 - N's Castle
328 - Route 10
329 - Skyarrow Bridge
330 - Icirrus City
331 - Driftveil Drawbridge
332 - Relic Castle
333 - Tubeline Bridge
334 - Marvelous Bridge
335 - Striaton City
336 - Driftveil City
337 - Mistralton City
339 - Kyurem Battle
340 - Reshiram/Zekrom Battle
341 - Legendary Pokemon Battle
342 - Encounter Parasol Lady
343 - Pokemon League
344 - World Champion
345 - N's Farewell
346 - Gate
347 - Battle Subway Trainer
348 - vs N Final
349 - vs Ghetsis
350 - Route 12 Spring
351 - Undella Town Spring
352 - Encounter Bianca
353 - Black City
354 - White Forest
355 - Anville Town
356 - Village Bridge
357 - Gear Station
358 - Gym Leader Last Pokemon
359 - Encounter Ace Trainer
360 - Encounter Backpacker
361 - Encounter Champ Alder
362 - Encounter Clerk
363 - Encounter Cyclist
364 - Encounter Gentleman
365 - Encounter N
366 - Encounter PokeFan
367 - Encounter Psychic
368 - Encounter Roughneck
369 - Encounter Twins
370 - Shopping Mall / Mart
371 - Juniper Father Theme
372 - Dragonspiral Tower Top
373 - Low Health